from sqlalchemy import MetaData
from .database import Base

# Optional: SQLAlchemy base metadata
metadata = Base.metadata

# You can add any common model configurations here
# For example, common columns, mixins, etc.
