"""
Repository package for data access layer.

This package contains repository implementations following the Repository pattern
for clean separation of concerns and testability.
"""
